# Change Log
The format is based on [Keep a Changelog](http://keepachangelog.com/) 
and [Semantic Versioning](http://semver.org/).


## [1.0.0] - 2016-08-21
### Added
- Changelog file
- Chrome support
- Options

### Changed
- Extension rewritten from Add-on SDK to WebExtensions
- Logic around radio buttons
- show.html file (for dev purposes)
